package chat.client;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

import chat.client.Room;
import chat.client.Service;

public class Server implements Runnable {

	// ServerŬ����: ������ ���� ���Ӽ���, ����Ŭ���̾�Ʈ ����

	Vector<Service> allV;
	Vector<Service> waitV;
	Vector<Room> roomV;

	public Server() {

		allV = new Vector<>();
		waitV = new Vector<>();
		roomV = new Vector<>();
		new Thread(this).start();
	}
	@SuppressWarnings({ "resource", "unused" })
	@Override
	public void run() {
		try {
			ServerSocket ss = new ServerSocket(1111);
			System.out.println("Start Server.......");
			while (true) {
				Socket s = ss.accept();
				Service ser = new Service(s, this);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}// run
	public static void main(String[] args) {
		new Server();
	}
}