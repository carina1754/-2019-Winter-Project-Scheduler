package application;
 
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.Timer;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
 
import first.*;
public class MainController{
	Calendar cal = Calendar.getInstance();
	Model model = new Model();
	private int nowDate = cal.get(Calendar.DATE);
	private int nowMonth = cal.get(Calendar.MONTH);
	private int nowYear = cal.get(Calendar.YEAR);

	@FXML
	private Text month;
	@FXML
	private Text year;
	@FXML
	private String calDate[][] = new String[6][7];
	@FXML
	private ArrayList<String> scheduleList = new ArrayList<>();
	@FXML
	private ListView<String> list = new ListView<>();
	private ObservableList<String> listItems;
	@FXML
	private Button PrevMonthButton;
	@FXML
	private Button NextMonthButton;
	@FXML
	private Button PrevYearButton;
	@FXML
	private Button NextYearButton;
	@FXML
	private Button addBtn;
	@FXML
	private Button delBtn;
	@FXML
	private TextField txtAddItem;

	@FXML
	private Button btn1;
	@FXML
	private Button btn2;
	@FXML
	private Button btn3;
	@FXML
	private Button btn4;
	@FXML
	private Button btn5;
	@FXML
	private Button btn6;
	@FXML
	private Button btn7;
	@FXML
	private Button btn8;
	@FXML
	private Button btn9;
	@FXML
	private Button btn10;
	@FXML
	private Button btn11;
	@FXML
	private Button btn12;
	@FXML
	private Button btn13;
	@FXML
	private Button btn14;
	@FXML
	private Button btn15;
	@FXML
	private Button btn16;
	@FXML
	private Button btn17;
	@FXML
	private Button btn18;
	@FXML
	private Button btn19;
	@FXML
	private Button btn20;
	@FXML
	private Button btn21;
	@FXML
	private Button btn22;
	@FXML
	private Button btn23;
	@FXML
	private Button btn24;
	@FXML
	private Button btn25;
	@FXML
	private Button btn26;
	@FXML
	private Button btn27;
	@FXML
	private Button btn28;
	@FXML
	private Button btn29;
	@FXML
	private Button btn30;
	@FXML
	private Button btn31;
	@FXML
	private Button btn32;
	@FXML
	private Button btn33;
	@FXML
	private Button btn34;
	@FXML
	private Button btn35;
	@FXML
	private Button btn36;
	@FXML
	private Button btn37;
	@FXML
	private Button btn38;
	@FXML
	private Button btn39;
	@FXML
	private Button btn40;
	@FXML
	private Button btn41;
	@FXML
	private Button btn42;

	public Button[] arrayButtons;
	
    @FXML
    private Label Login;
    @FXML
    private TextField txtUserName;
    @FXML
    private TextField txtPassword;
    
    @FXML
    private TextField NewUserName;
    
    @FXML
    private TextField NewPassWord;
    @FXML
    private TextField RePassWord;
    
    @FXML
    private Button login;
    
    @FXML
    private Button join;
    
    @FXML
    private Button loginpage;
    
    public void Login(ActionEvent event) throws Exception{
        try {
        if(txtUserName.getText().equals("name") && txtPassword.getText().equals("pass")){
            Login.setText("Login Success");
            Stage primaryStage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/application/design.fxml"));
            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();
            Stage stage1 = (Stage) Login.getScene().getWindow();
       	    stage1.close();
            TestSystemTrayIcon test = new TestSystemTrayIcon();
        }else{
            Login.setText("Login Failed");
        }
        }
        catch (IOException e) {
       		// TODO Auto-generated catch block
       		e.printStackTrace();
       	}
    }
    
    
    public void JoinPop(ActionEvent event) {
   	 Parent root;
   	try {
   		
   		root = FXMLLoader.load(getClass().getResource("/application/join.fxml"));
   	    Scene scene = new Scene(root);
   	    Stage stage = new Stage();
   	    stage.setScene(scene);
   	    stage.show();
   		Stage stage1 = (Stage) Login.getScene().getWindow();
	    stage1.close();
   	} catch (IOException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
   	}
    
    public void ReLogin(ActionEvent event) {
    	Parent root;
       	try {
       		root = FXMLLoader.load(getClass().getResource("/application/main.fxml"));
       	    Scene scene = new Scene(root);
       	    Stage stage = new Stage();
       	    stage.setScene(scene);
       	    stage.show();
       	    Stage stage1 = (Stage) NewPassWord.getScene().getWindow();
       	    stage1.close();
       	} catch (IOException e) {
       		// TODO Auto-generated catch block
       		e.printStackTrace();
       	}
    }
    
    public void MainPage(int n) {
    	if (n==1) {
    	Parent root;
    	try {
       		root = FXMLLoader.load(getClass().getResource("/application/design.fxml"));
       	    Scene scene = new Scene(root);
       	    Stage stage = new Stage();
       	    stage.setScene(scene);
       	    stage.show();
       	} catch (IOException e) {
       		// TODO Auto-generated catch block
       		e.printStackTrace();
       	}}
    }
    
	public void prevMonth(ActionEvent event) {
		if (--nowMonth < 0) {
			nowMonth = 11;
			nowYear--;
		}
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}

	
	public void nextMonth(ActionEvent event) {
		if (++nowMonth > 11) {
			nowMonth = 0;
			nowYear++;
		}
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}

	
	public void prevYear(ActionEvent event) {
		nowYear--;
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}

	
	public void nextYear(ActionEvent event) {
		nowYear++;
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}


	public void setButton() {
		arrayButtons = new Button[42];
		arrayButtons[0] = btn1;
		arrayButtons[1] = btn2;
		arrayButtons[2] = btn3;
		arrayButtons[3] = btn4;
		arrayButtons[4] = btn5;
		arrayButtons[5] = btn6;
		arrayButtons[6] = btn7;
		arrayButtons[7] = btn8;
		arrayButtons[8] = btn9;
		arrayButtons[9] = btn10;
		arrayButtons[10] = btn11;
		arrayButtons[11] = btn12;
		arrayButtons[12] = btn13;
		arrayButtons[13] = btn14;
		arrayButtons[14] = btn15;
		arrayButtons[15] = btn16;
		arrayButtons[16] = btn17;
		arrayButtons[17] = btn18;
		arrayButtons[18] = btn19;
		arrayButtons[19] = btn20;
		arrayButtons[20] = btn21;
		arrayButtons[21] = btn22;
		arrayButtons[22] = btn23;
		arrayButtons[23] = btn24;
		arrayButtons[24] = btn25;
		arrayButtons[25] = btn26;
		arrayButtons[26] = btn27;
		arrayButtons[27] = btn28;
		arrayButtons[28] = btn29;
		arrayButtons[29] = btn30;
		arrayButtons[30] = btn31;
		arrayButtons[31] = btn32;
		arrayButtons[32] = btn33;
		arrayButtons[33] = btn34;
		arrayButtons[34] = btn35;
		arrayButtons[35] = btn36;
		arrayButtons[36] = btn37;
		arrayButtons[37] = btn38;
		arrayButtons[38] = btn39;
		arrayButtons[39] = btn40;
		arrayButtons[40] = btn41;
		arrayButtons[41] = btn42;

		int row = 0;
		int col = 0;
		for (int i = 0; i < 42; i++) {
			arrayButtons[i].setText(calDate[row][col]);
			col++;
			if (col % 7 == 0) {
				row++;
				col = 0;
			}
		}
	}

	public void setDate() {
		// �떖�젰 �궇吏� 諛곗뿴�뿉 ���옣
		int width = calDate[0].length;

		cal.set(Calendar.DATE, 1);

		int startDay = cal.get(Calendar.DAY_OF_WEEK);
		int lastDay = cal.getActualMaximum(Calendar.DATE);
		int inputDate = 1;

		int row = 0;
		for (int i = 1; i <= 42; i++) {
			if (i < startDay) {
				calDate[row][(i - 1) % width] = "";
			} else if (inputDate > lastDay) {
				calDate[row][(i - 1) % width] = "";
			} else {
				calDate[row][(i - 1) % width] = Integer.toString(inputDate);
				inputDate++;
			}

			if (i % width == 0)
				row++;
		}
	}

	
	   public void initialize(URL url, ResourceBundle rb) {
	      listItems = FXCollections.observableArrayList("Today' Schedule");
	      list.setItems(listItems);

	      // Disable buttons to start
	      addBtn.setDisable(true);
	      delBtn.setDisable(true);

	      // Add a ChangeListener to TextField to look for change in focus
	      txtAddItem.focusedProperty().addListener(new ChangeListener<Boolean>() {
	         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
	            if (txtAddItem.isFocused()) {
	               addBtn.setDisable(false);
	            }
	         }
	      });

	      // Add a ChangeListener to ListView to look for change in focus
	      list.focusedProperty().addListener(new ChangeListener<Boolean>() {
	         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
	            if (list.isFocused()) {
	               delBtn.setDisable(false);
	            }
	         }
	      });

			setDate();

			setButton();

			model.setMonthCode(cal.get(Calendar.MONTH));
			month.setText(model.monthCode);
			year.setText(Integer.toString(nowYear));
	   }


	public void addSchedule(ActionEvent e) {
		listItems.add(txtAddItem.getText());
		System.out.println("add");
		txtAddItem.clear();
	}

	public void delSchedule(ActionEvent e) {
		int selectedItem = list.getSelectionModel().getSelectedIndex();
		listItems.remove(selectedItem);
	}
	
}