package application;
import java.awt.AWTException;
import application.Main;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import application.MainController;
public class TestSystemTrayIcon implements ActionListener {
	private SystemTray systemTray;
	private PopupMenu mPopup;
	private MenuItem mItemMain, mItemToday, mItemEventDay, mItemExit;

	public TestSystemTrayIcon() {
		try {
			initSystemTrayIcon();
		} catch (AWTException awte) {
			System.out.println("##### Error occurred during create UI!!!");
			System.out.println(awte.toString());
			System.exit(0);
		}
	}

	public void initSystemTrayIcon() throws AWTException {
		if (SystemTray.isSupported()) {
			mPopup = new PopupMenu();
			mItemMain = new MenuItem("�޷� ����");
			mItemToday = new MenuItem("���� ���� ����");
			mItemEventDay = new MenuItem("Ư�� ���� ����");
			mItemExit = new MenuItem("���α׷� ����");

			mItemMain.addActionListener(this);
			mItemToday.addActionListener(this);
			mItemEventDay.addActionListener(this);
			mItemExit.addActionListener(this);

			mPopup.add(mItemMain);
			mPopup.addSeparator();
			mPopup.add(mItemToday);
			mPopup.add(mItemEventDay);
			mPopup.addSeparator();
			mPopup.add(mItemExit);

			Image image = Toolkit.getDefaultToolkit().getImage("C:\\Users\\JUNG-SU\\Desktop\\login page image.png");
			TrayIcon trayIcon = new TrayIcon(image, "Ķ����(Scheduler)", mPopup);
			trayIcon.setImageAutoSize(true);

			systemTray = SystemTray.getSystemTray();
			systemTray.add(trayIcon);
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		MainController Login = new MainController();
		if (ae.getSource() == mItemMain) {
			Login.MainPage(1);
		} else if (ae.getSource() == mItemToday) {
			Login.MainPage(2);
		} else if (ae.getSource() == mItemEventDay) {
			Login.MainPage(3);
		} else if (ae.getSource() == mItemExit) {
			System.exit(0);
		}
	}

	private void showMessage(String title, String message) {
		JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
	}

	public static void main(String[] args) {
		TestSystemTrayIcon test = new TestSystemTrayIcon();
	}
}