package first;
import java.awt.AWTException;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import application.*;
public class TestSystemTrayIcon implements ActionListener {
	private SystemTray systemTray;
	private PopupMenu mPopup;
	private MenuItem mItemMain, mItemToday, mItemEventDay, mItemExit;

	public TestSystemTrayIcon() {
		try {
			initSystemTrayIcon();
		} catch (AWTException awte) {
			System.out.println("##### Error occurred during create UI!!!");
			System.out.println(awte.toString());
			System.exit(0);
		}
	}

	public void initSystemTrayIcon() throws AWTException {
		if (SystemTray.isSupported()) {
			mPopup = new PopupMenu();
			mItemMain = new MenuItem("�޷� ����");
			mItemToday = new MenuItem("���� ���� ����");
			mItemEventDay = new MenuItem("Ư�� ���� ����");
			mItemExit = new MenuItem("���α׷� ����");

			mItemMain.addActionListener(this);
			mItemToday.addActionListener(this);
			mItemEventDay.addActionListener(this);
			mItemExit.addActionListener(this);

			mPopup.add(mItemMain);
			mPopup.addSeparator();
			mPopup.add(mItemToday);
			mPopup.add(mItemEventDay);
			mPopup.addSeparator();
			mPopup.add(mItemExit);

			Image image = Toolkit.getDefaultToolkit().getImage("C:\\Users\\JUNG-SU\\Desktop\\login page image.png");
			TrayIcon trayIcon = new TrayIcon(image, "Ķ����(Scheduler)", mPopup);
			trayIcon.setImageAutoSize(true);

			systemTray = SystemTray.getSystemTray();
			systemTray.add(trayIcon);
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == mItemMain) {
			
		} else if (ae.getSource() == mItemToday) {
			showMessage("File Open...", "������ ���ϴ�.");
		} else if (ae.getSource() == mItemEventDay) {
			showMessage("File Save...", "������ �����մϴ�.");
		} else if (ae.getSource() == mItemExit) {
			showMessage("Exit SystemTrayIcon Test...", "�����ϰڽ��ϴ�.");
			System.exit(0);
		}
	}

	private void showMessage(String title, String message) {
		JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
	}

	public static void main(String[] args) {
		TestSystemTrayIcon test = new TestSystemTrayIcon();
	}
}