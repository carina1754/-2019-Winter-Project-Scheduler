package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class SampleController implements Initializable {
	Calendar cal = Calendar.getInstance();
	Model model = new Model();
	private int nowDate = cal.get(Calendar.DATE);
	private int nowMonth = cal.get(Calendar.MONTH);
	private int nowYear = cal.get(Calendar.YEAR);

	@FXML
	private Text month;
	@FXML
	private Text year;
	@FXML
	private String calDate[][] = new String[6][7];
	@FXML
	private ArrayList<String> scheduleList = new ArrayList<>();
	@FXML
	private ListView<String> list = new ListView<>();
	private ObservableList<String> listItems;

	@FXML
	private Button addBtn;
	@FXML
	private Button delBtn;
	@FXML
	private TextField txtAddItem;

	@FXML
	private Button btn1;
	@FXML
	private Button btn2;
	@FXML
	private Button btn3;
	@FXML
	private Button btn4;
	@FXML
	private Button btn5;
	@FXML
	private Button btn6;
	@FXML
	private Button btn7;
	@FXML
	private Button btn8;
	@FXML
	private Button btn9;
	@FXML
	private Button btn10;
	@FXML
	private Button btn11;
	@FXML
	private Button btn12;
	@FXML
	private Button btn13;
	@FXML
	private Button btn14;
	@FXML
	private Button btn15;
	@FXML
	private Button btn16;
	@FXML
	private Button btn17;
	@FXML
	private Button btn18;
	@FXML
	private Button btn19;
	@FXML
	private Button btn20;
	@FXML
	private Button btn21;
	@FXML
	private Button btn22;
	@FXML
	private Button btn23;
	@FXML
	private Button btn24;
	@FXML
	private Button btn25;
	@FXML
	private Button btn26;
	@FXML
	private Button btn27;
	@FXML
	private Button btn28;
	@FXML
	private Button btn29;
	@FXML
	private Button btn30;
	@FXML
	private Button btn31;
	@FXML
	private Button btn32;
	@FXML
	private Button btn33;
	@FXML
	private Button btn34;
	@FXML
	private Button btn35;
	@FXML
	private Button btn36;
	@FXML
	private Button btn37;
	@FXML
	private Button btn38;
	@FXML
	private Button btn39;
	@FXML
	private Button btn40;
	@FXML
	private Button btn41;
	@FXML
	private Button btn42;

	public Button[] arrayButtons;

	@FXML
	private void prevMonth() {
		if (--nowMonth < 0) {
			nowMonth = 11;
			nowYear--;
		}
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}

	@FXML
	private void nextMonth() {
		if (++nowMonth > 11) {
			nowMonth = 0;
			nowYear++;
		}
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}

	@FXML
	private void prevYear() {
		nowYear--;
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}

	@FXML
	private void nextYear() {
		nowYear++;
		cal.set(Calendar.YEAR, nowYear);
		cal.set(Calendar.MONTH, nowMonth);

		setDate();

		setButton();

		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);
		year.setText(Integer.toString(nowYear));

		System.out.println(nowYear);
		System.out.println(nowMonth);
	}

	public void setButton() { // 버튼마다 날짜를 지정하기 편하게 하려고 버튼을 배열에 할당
		arrayButtons = new Button[42];
		arrayButtons[0] = btn1;
		arrayButtons[1] = btn2;
		arrayButtons[2] = btn3;
		arrayButtons[3] = btn4;
		arrayButtons[4] = btn5;
		arrayButtons[5] = btn6;
		arrayButtons[6] = btn7;
		arrayButtons[7] = btn8;
		arrayButtons[8] = btn9;
		arrayButtons[9] = btn10;
		arrayButtons[10] = btn11;
		arrayButtons[11] = btn12;
		arrayButtons[12] = btn13;
		arrayButtons[13] = btn14;
		arrayButtons[14] = btn15;
		arrayButtons[15] = btn16;
		arrayButtons[16] = btn17;
		arrayButtons[17] = btn18;
		arrayButtons[18] = btn19;
		arrayButtons[19] = btn20;
		arrayButtons[20] = btn21;
		arrayButtons[21] = btn22;
		arrayButtons[22] = btn23;
		arrayButtons[23] = btn24;
		arrayButtons[24] = btn25;
		arrayButtons[25] = btn26;
		arrayButtons[26] = btn27;
		arrayButtons[27] = btn28;
		arrayButtons[28] = btn29;
		arrayButtons[29] = btn30;
		arrayButtons[30] = btn31;
		arrayButtons[31] = btn32;
		arrayButtons[32] = btn33;
		arrayButtons[33] = btn34;
		arrayButtons[34] = btn35;
		arrayButtons[35] = btn36;
		arrayButtons[36] = btn37;
		arrayButtons[37] = btn38;
		arrayButtons[38] = btn39;
		arrayButtons[39] = btn40;
		arrayButtons[40] = btn41;
		arrayButtons[41] = btn42;

		int row = 0;
		int col = 0;
		for (int i = 0; i < 42; i++) {
			arrayButtons[i].setText(calDate[row][col]);
			col++;
			if (col % 7 == 0) {
				row++;
				col = 0;
			}
		}
	}

	public void setDate() {
		// 달력 날짜를 배열에 저장
		int width = calDate[0].length;

		cal.set(Calendar.DATE, 1);

		int startDay = cal.get(Calendar.DAY_OF_WEEK);
		int lastDay = cal.getActualMaximum(Calendar.DATE);
		int inputDate = 1;

		int row = 0;
		for (int i = 1; i <= 42; i++) {
			if (i < startDay) {
				calDate[row][(i - 1) % width] = "";
			} else if (inputDate > lastDay) {
				calDate[row][(i - 1) % width] = "";
			} else {
				calDate[row][(i - 1) % width] = Integer.toString(inputDate);
				inputDate++;
			}

			if (i % width == 0)
				row++;
		}
	}

	// 여기서부터는 옆에뜨는 요상한 리스트에 대한 코드이므로 신경쓰지않아도 됩니당....
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		listItems = FXCollections.observableArrayList("Today' Schedule");
		list.setItems(listItems);

		// Disable buttons to start
		addBtn.setDisable(true);
		delBtn.setDisable(true);

		// Add a ChangeListener to TextField to look for change in focus
		txtAddItem.focusedProperty().addListener(new ChangeListener<Boolean>() {
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (txtAddItem.isFocused()) {
					addBtn.setDisable(false);
				}
			}
		});

		// Add a ChangeListener to ListView to look for change in focus
		list.focusedProperty().addListener(new ChangeListener<Boolean>() {
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (list.isFocused()) {
					delBtn.setDisable(false);
				}
			}
		});

		//날짜 화면 초기화
		// 날짜 배열에 저장
		setDate();

		// 날짜 버튼 세팅
		setButton();

		// 현재 월
		model.setMonthCode(cal.get(Calendar.MONTH));
		month.setText(model.monthCode);

		// 현재 연도
		year.setText(Integer.toString(cal.get(Calendar.YEAR)));
	}

	@FXML
	private void addSchedule(ActionEvent e) {
		listItems.add(txtAddItem.getText());
		System.out.println("add");
		txtAddItem.clear();
	}

	@FXML
	private void delSchedule(ActionEvent e) {
		int selectedItem = list.getSelectionModel().getSelectedIndex();
		listItems.remove(selectedItem);
	}
}
